IBM WSRP 2.0 Producer for WebSphere Application Server
(C) Copyright IBM Corporation 2013.

Documentation
-------------
The documentation is available online:
http://www-10.lotus.com/ldd/portalwiki.nsf/xpDocViewer.xsp?lookupName=IBM WSRP 2.0 Producer for WebSphere Application Server#action=openDocument&content=catcontent&ct=prodDoc

Change History
--------------

8.5.5.3
- Fixed the following issue:
  - WSRP responses may contain an incorrect return type.
- Added environment entries to configure the WSRP Producer to disable specific WSRP response data structures  
  that may cause errors on certain non-IBM WSRP consumers. You should enable this configuration only if you
  are using non-IBM consumers and there are errors while processing a service description response
  or a getMarkup or getResource response containing binary content.
  To disable service description extensions set the environment entry wsrp.servicedescription.extensions.enabled = false
  and restart the WSRP Producer application.
  To disable binary content in a getMarkup or getResource response, set wsrp.encodeBinaryContent.charset = <charset>
  where <charset> denotes the charset that is used for encoding the binary content. The value "default" denotes the
  default charset. If this environment entry is set the WSRP Producer does not return binary content, but encodes the
  binary content and returns the resulting string representation.

8.5.5.2
- Fixed the following issues:
  - The environment entry wsrp.security.disabled is ignored if the authorization provider plugin is deployed.
  - The producer does not retrieve extendedURLParameters sent by a Portal 6.1 Consumer
- Added support to disable the periodic reload of the portlet pool.
  (See page "Setting the portlet pool reload interval" in the online documentation.)
  You can now specify a negative integer value (e.g. "-1") for the environment entry in order to 
  disable the periodic reload of the portlet pool.

8.5.5.1
- Added an extension point for registering SOAP handlers (available on WebSphere Application Server Full Profile only).
  See "Using a web service handler on the WSRP Producer" in the documentation for more information.
- Added support for the releaseSessions operation (available on WebSphere Application Server Full Profile only).
  A Consumer can invoke this operation in order to release producer side sessions,
  passing a session id cookie as part of the request.
  The producer will invalidate the sessions identified by the session id cookie.
- Added support for new WSRP extensions introduced with WebSphere Portal 8.5 CF 05.
- On WebSphere Application Server Version 8.5.5 Liberty Profile the WSRP Producer requires the 
  March 2015 (or newer) release of the IBM Portlet Container for WebSphere Application Server Liberty Profile.

8.5.5
- Added support for WebSphere Application Server Version 8.5.x Full Profile and for
  WebSphere Application Server Version 8.5.5 Liberty Profile.
  The WSRP Producer now supports 
  - WebSphere Application Server Version 8.5.x Full Profile
  - WebSphere Application Server Version 8.5.5 Liberty Profile
  - WebSphere Application Server Version 8.0 Full Profile
  - WebSphere Application Server Version 7.0
- The WSRP webservices implementation now complies to the JAX-WS standard.
  The WSRP Producer is rebased on the JAX-WS standard and provides a set of
  JAX-WS compliant service providers.
- On WebSphere Application Server Version 8.5.5 Liberty Profile the WSRP Producer requires the features 
  Java API for XML-based Web Services (JAX-WS) and 
  IBM Portlet Container for WebSphere Application Server Liberty Profile.
  Both features must be installed and enabled.
- On WebSphere Application Server Version 8.5.5 Liberty Profile the WSRP Producer
  requires APAR PI05575. 

7.0.0.5
- fix: PM82212: If portlet fragment caching or servlet caching is enabled in WAS, the getMarkup operation fails
  due to a ClassCastException that occurs on the producer side (in StoredResponse).

7.0.0.4
- added translations for error messages

7.0.0.3
- fix: PM60101: WSRP producer ignores extendedURLParameters sent by a Portal 7 consumer

7.0.0.2
- added support for JSR286 2-phase rendering
  For the getMarkup() operation, the Producer runtime now invokes the portlet container with the RENDER_PARTs
  RENDER_HEADERS & RENDER_MARKUP. This happens for JSR286 portlets which have declared 2-phase-rendering
  support in their portlet.xml.
  This allows portlets to set response headers, cookies, and head section contributions in the
  RENDER_HEADERS sub-phase.
  Cookies are returned on the transport layer with the Web Service response.
  Other response properties are send via the WSRP protocol payload as ClientAttributes.
  Head section contributions are returned back to the Consumer with a custom IBM extension since
  WSRP does not support 2-phase-rendering per se. This IBM extension is also supported
  with WebSphere Portal 7.x. Other Consumers not supporting this extension will likely ignore the
  head section contributions of remote portlets.
- fix: PM56224: ClientAttributes sent by a Consumer are now accessible via PortletRequest properties.
                Those can be e.g. HTTP headers sent by the browser to the Consumer. 

7.0.0.1
- added WebSphere Application Server 8.0 support
  Note: WAS8 sends a httpOnly attribute with session cookies. This is not always supported by all
        web service clients. In this case you can disable the sending of the httpOnly attribute in
        the WAS admin console by navigating to the WSRP Producer web app to:
        1. Enterprise Applications > WSRP Producer > Session management > Cookies
        2. uncheck the selection for "Set session cookies to HTTPOnly to help prevent cross-site scripting attacks "
        3. in Enterprise Applications > WSRP Producer > Session management check the selection "Override session management"
        4. restart the app
        Remark: In the WSRP case the cookies for managing the session are exchanged between the WSRP Consumer and Producer.
                The cookie typically is never passed to the client (Browser). Therefore the cross-site scripting threat
                does not apply here anyway.
		Using WebSphere Portal as the Consumer: An APAR PM40899 has been provided to add support for the httpOnly
		attribute. Please install this APAR on WebSphere Portal. Once installed there is no need for disabling the
		httpOnly attribute on WAS8.                 
- fix: getServiceDescription() fails if accessed via WSRP1.0 & 2.0 at the same time 

7.0.0.0
- initial version

Trademarks
----------
The following terms are trademarks in the United States, other countries, or both.

IBM, the IBM logo, and WebSphere are trademarks of the International Business
Machines Corporation Corporation in the United States, other countries, or both.